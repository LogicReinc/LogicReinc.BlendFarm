LogicReinc.BlendFarm
------------------------

Since this application is not signed or registered with our Apple overlords, you will have to right-click=>open LogicReinc.BlendFarm.app the first time to tell GateKeeper to trust it. Afterward the first time you can just doubleclick the .app

At this time I don't plan on registering as Apple developer.



https://github.com/LogicReinc/LogicReinc.BlendFarm
https://www.patreon.com/LogicReinc